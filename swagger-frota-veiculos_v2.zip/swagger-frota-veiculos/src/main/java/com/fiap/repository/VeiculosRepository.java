package com.fiap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fiap.models.Veiculos;

public interface VeiculosRepository extends JpaRepository<Veiculos, Long> {

}
